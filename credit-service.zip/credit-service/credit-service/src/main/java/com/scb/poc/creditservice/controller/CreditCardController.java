package com.scb.poc.creditservice.controller;

import com.scb.poc.creditservice.entity.CreditCard;
import com.scb.poc.creditservice.service.CreditService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/card")
public class CreditCardController {

    @Autowired
    private CreditService creditService;

    @PostMapping("/")
    public CreditCard saveCreditCard(@RequestBody CreditCard creditCard){
        log.info("Save card method inside credit controller");
        return creditService.saveCreditCard(creditCard);
    }

    @GetMapping("/{id}")
    public CreditCard getCreditCardDetailsByID(@PathVariable("id") Integer cardId){
        return creditService.getCardDetailsById(cardId);
    }
}
