package com.scb.poc.creditservice.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="CreditCard")
public class CreditCard {
    @Id
    @GeneratedValue(strategy =GenerationType.AUTO)
    private int cardID;
    private int cardLimit;
    private String cardHolderName;
    private String cardStatus;
}
