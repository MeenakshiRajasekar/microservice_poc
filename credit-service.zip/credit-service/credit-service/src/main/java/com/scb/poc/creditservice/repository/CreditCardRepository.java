package com.scb.poc.creditservice.repository;

import com.scb.poc.creditservice.entity.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, Integer> {

    CreditCard getCardDetailsBycardID(Integer cardID);
}
