package com.scb.poc.creditservice.service;

import com.scb.poc.creditservice.entity.CreditCard;
import com.scb.poc.creditservice.repository.CreditCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CreditService {

    @Autowired
    private CreditCardRepository creditCardRepository;


    public CreditCard saveCreditCard(CreditCard creditCard){

        return creditCardRepository.save(creditCard);
    }

    public CreditCard getCardDetailsById(Integer cardID){
        return creditCardRepository.getCardDetailsBycardID(cardID);
    }

}
