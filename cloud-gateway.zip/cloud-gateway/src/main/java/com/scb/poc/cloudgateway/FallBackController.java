package com.scb.poc.cloudgateway;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackController {

    @GetMapping("/userServiceFallBack")
    public String userServiceFallBackMethod(){
        return "User service is taking longer than expected" +
                "Please try again later";
    }

    @GetMapping("/cardServiceFallBack")
    public String cardServiceFallBackMethod(){
        return "Card service is taking longer than expected" +
                "Please try again later";
    }

    @GetMapping("/loanServiceFallBack")
    public String loanServiceFallBackMethod(){
        return "Loan service is taking longer than expected" +
                "Please try again later";
    }
}
