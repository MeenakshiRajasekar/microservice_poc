package com.scb.poc.loanservice.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="Loan")
public class Loan {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int loanID;
    private int loanLimit;
    private String loanType;
    private long loanAmount;
    private String loanStatus;
    private String debtorName;
}
