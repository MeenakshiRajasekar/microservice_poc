package com.scb.poc.loanservice.repository;

import com.scb.poc.loanservice.entity.Loan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Integer> {
    Loan findLoanByloanID(Integer loanID);
}
