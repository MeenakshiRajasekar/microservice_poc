package com.scb.poc.loanservice.controller;

import com.fasterxml.jackson.databind.node.FloatNode;
import com.scb.poc.loanservice.entity.Loan;
import com.scb.poc.loanservice.service.LoanService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/loan")
@Slf4j
public class LoanController {

    @Autowired
    private LoanService loanService;

    @PostMapping("/")
    public Loan saveLoan(@RequestBody Loan loan){
        log.info("save loan method inside loan controller");
        return  loanService.saveLoan(loan);
    }

    @GetMapping("/{id}")
    public Loan getLoanByLoanID(@PathVariable("id") Integer loanID){
        return loanService.getLoanbyLoanID(loanID);
    }
}
