package com.scb.poc.user.commons;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreditCard {

    private int cardID;
    private int cardLimit;
    private String cardHolderName;
    private String cardStatus;
}
