package com.scb.poc.user.controller;

import com.scb.poc.user.commons.ResponseTemplateVO;
import com.scb.poc.user.entity.User;
import com.scb.poc.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/")
    public User saveUser(@RequestBody User user){
        log.info("Save user method of user controller");
        return userService.saveUser(user);
    }

//    @GetMapping("/{id}")
//    public User findUserById(@PathVariable("id") Integer userId){
//        log.info("Find user method of user controller");
//        return userService.findUserById(userId);
//    }
    @GetMapping("/{id}")
    public ResponseTemplateVO findCardDetailsByUserId(@PathVariable("id") Integer userId){
        log.info("Fetch card details by user id");
        return userService.findCardDetailsByUserID(userId);
    }

    @GetMapping("/cardloan/{id}")
    public ResponseTemplateVO findLoanDetailsByUserId(@PathVariable("id") Integer userId){
        log.info("Fetch loan details by user id");
        return userService.findLoanDetailsByUserID(userId);
    }
}
