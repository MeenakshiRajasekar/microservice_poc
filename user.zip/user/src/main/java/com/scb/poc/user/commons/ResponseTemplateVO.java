package com.scb.poc.user.commons;

import com.scb.poc.user.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseTemplateVO {

    private User user;
    private CreditCard creditCard;
    private Loan loan;
}
