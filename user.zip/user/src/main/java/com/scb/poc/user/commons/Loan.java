package com.scb.poc.user.commons;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Loan {
    private int loanID;
    private int loanLimit;
    private String loanType;
    private long loanAmount;
    private String loanStatus;
    private String debtorName;
}
