package com.scb.poc.user.service;

import com.scb.poc.user.commons.CreditCard;
import com.scb.poc.user.commons.Loan;
import com.scb.poc.user.commons.ResponseTemplateVO;
import com.scb.poc.user.entity.User;
import com.scb.poc.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    public User findUserById(Integer userId) {
        //jpa repository - to write methods(rules)
        return userRepository.findUserByUserID(userId);
    }

    public ResponseTemplateVO findCardDetailsByUserID(Integer userId) {
        ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
        User user = userRepository.findUserByUserID(userId);
        CreditCard creditCard = restTemplate.getForObject("http://CREDIT-SERVICE/card/"+user.getCardID(),
                CreditCard.class);
        responseTemplateVO.setUser(user);
        responseTemplateVO.setCreditCard(creditCard);
        return responseTemplateVO;
    }

    public ResponseTemplateVO findLoanDetailsByUserID(Integer userId) {
        ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
        User user = userRepository.findUserByUserID(userId);
        Loan loan = restTemplate.getForObject("http://LOAN-SERVICE/loan/" +user.getLoanID()
                ,Loan.class);
        CreditCard creditCard = restTemplate.getForObject("http://CREDIT-SERVICE/card/"+user.getCardID(),
                CreditCard.class);
        responseTemplateVO.setUser(user);
        responseTemplateVO.setLoan(loan);
        responseTemplateVO.setCreditCard(creditCard);
        return responseTemplateVO;
    }
}
